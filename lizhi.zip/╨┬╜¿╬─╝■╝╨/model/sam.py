# copyright ziqi-jin
import torch
import torch.nn as nn
from .segment_anything_ori import sam_model_registry
from .image_encoder import BaseImgEncodeAdapter
from .mask_decode import BaseMaskDecoderAdapter, SemMaskDecoderAdapter
from .prompt_encoder import BasePromptEncodeAdapter


class Finetune_Sam(nn.Module):

    def __init__(self, ckpt_path=None, fix_img_en=False, fix_prompt_en=False, fix_mask_de=False, model_type='vit_b'):
        super(Finetune_Sam, self).__init__()
        assert model_type in ['default', 'vit_b', 'vit_l', 'vit_h'], print(
            "Wrong model_type, SAM only can be built as vit_b, vot_l, vit_h and default ")
        self.ori_sam = sam_model_registry[model_type](ckpt_path)
        self.img_encoder = BaseImgEncodeAdapter(self.ori_sam, fix=fix_img_en)
        self.prompt_encoder = BasePromptEncodeAdapter(self.ori_sam, fix=fix_prompt_en)
        self.mask_encoder = BaseMaskDecoderAdapter(self.ori_sam, fix=fix_mask_de)

    def forward(self, img):
        x = self.img_encoder(img)
        points = None
        boxes = None
        masks = None

        sparse_embeddings, dense_embeddings = self.prompt_encoder(
            points=points,
            boxes=boxes,
            masks=masks,
        )
        
        multimask_output = True
        
        low_res_masks, iou_predictions = self.mask_encoder(
            image_embeddings=x,
            prompt_encoder=self.prompt_encoder,
            sparse_embeddings=sparse_embeddings,
            dense_embeddings=dense_embeddings,
            multimask_output=multimask_output,
        )
        return low_res_masks, iou_predictions


class SemanticSam(Finetune_Sam):

    def __init__(self, ckpt_path=None, fix_img_en=False, fix_prompt_en=False, fix_mask_de=False, class_num=20, model_type='vit_b'):
        super().__init__(ckpt_path=ckpt_path, fix_img_en=fix_img_en, fix_prompt_en=fix_prompt_en,
                         fix_mask_de=fix_mask_de, model_type=model_type)
        self.mask_adapter = SemMaskDecoderAdapter(self.ori_sam, fix=fix_mask_de, class_num=class_num)