import torch
from transformers import Qwen2_5_VLForConditionalGeneration,AutoTokenizer, AutoProcessor
from PIL import Image, ImageDraw, ImageFont
import json
import os
from tqdm import tqdm
import numpy as np
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns
from collections import defaultdict
import re
from typing import List, Dict, Any, Tuple
from dataclasses import dataclass, field


from dataclasses import dataclass, field

@dataclass
class SampleResult:
    # 基本信息字段
    image_path: str  # 图像文件路径
    text: str        # 相关文本内容
    
    #  二分类的评估工具
    gt_class: bool    # 真实类别标签（是否是伪造图像）
    pred_class: bool  # 预测类别标签
    
    # 多分类的评估工具（可不止一种）
    face_swap_gt: bool
    face_swap_pred: bool
    face_attribute_gt: bool
    face_attribute_pred: bool
    
    text_swap_pred: bool
    text_swap_gt: bool
    text_attribute_pred: bool
    text_attribute_gt: bool
    
    # 伪造人脸的位置检测能力
    fake_face_gt_boxes: List[List[float]] = field(default_factory=list)      # 真实边界框坐标
    fake_face_pred_boxes: List[List[float]] = field(default_factory=list)    # 预测边界框坐标




class DGM4Evaluator:
    def __init__(self, model, tokenizer, processor, device: str = None, iou_thresh: float = 0.5):
        self.device = torch.device(device if device else ("cuda" if torch.cuda.is_available() else "cpu"))
        self.model = model
        self.tokenizer = tokenizer
        self.processor = processor
        self.iou_thresh = iou_thresh

        # DGM4 5类：四种操纵 + 原始
        self.class_names = {
            "face":["face_swap", "face_attribute"],
            "text":["text_swap", "text_attribute"],
            "ori":["orig"]
        }
        
        self.single_cls_preds: List[int] = []    # True:1  False:0
        self.single_cls_gts: List[int] = []  
        
        self.face_swap_cls_preds: List[int] = []
        self.face_swap_cls_gts: List[int] = []
        
        self.face_attribute_cls_preds: List[int] = []
        self.face_attribute_cls_gts: List[int] = []
        
        self.text_swap_cls_preds: List[int] = []
        self.text_swap_cls_gts: List[int] = []
        
        self.text_attribute_cls_preds: List[int] = []
        self.text_attribute_cls_gts: List[int] = []
        
    def _normalize_class(self, cls_str: str) -> str:
        '''
        处理类别文本，支持单个或多个类别（用&连接）

        Args:
            cls_str: 输入的类别字符串，可能包含多个类别用&连接

        Returns:
            str: 标准化后的类别字符串
        '''
        
        return_cls = {
            "read_success": False,
            "gt_class": False,

            # 多分类的评估工具（可不止一种）
            "face_swap_gt": False,
            "face_attribute_gt": False,

            "text_swap_gt": False,
            "text_attribute_gt": False
        }
        
        if not cls_str:
            return return_cls

        # 分割多个类别并处理每个类别
        classes = cls_str.strip().lower().split("&")

        for cls in classes:
            cls = cls.strip()
            if cls == "orig":
                return_cls["gt_class"] = True
            elif cls == 'face_swap':
                return_cls["face_swap_gt"] = True
            elif cls == 'face_attribute':
                return_cls["face_attribute_gt"] = True
            elif cls == 'text_swap':
                return_cls["text_swap_gt"] = True
            elif cls == 'text_attribute':
                return_cls["text_attribute_gt"] = True
            else:
                print(classes)
                return return_cls
            
        if return_cls["face_swap_gt"] or return_cls["face_attribute_gt"] or return_cls["text_swap_gt"] or return_cls["text_attribute_gt"]:
            return_cls['gt_class'] = False
            print("怀疑标签有误")
        else:
            return_cls["read_success"] = True
        
        return return_cls

    def _open_image(self, path: str):
        try:
            img = Image.open(path).convert("RGB")
            return img
        except Exception as e:
            print(f"[WARN] 打开图像失败 {path}: {e}")
            return None
        
    def _build_prompt(self, text: str) -> str:
        # 要求结构化JSON输出，便于稳健解析与评估
        prompt = ('''
        你是多模态篡改取证助手，十分擅长对图文数据进行分析，确认图文的真伪。现在给定一张新闻图片与其配文，请判断图像和文本是否被篡改、篡改类型，并定位篡改区域。
        对于图像的篡改类型主要分为两种：face_swap 是指人脸替换篡改，将图片中的人脸替换为了其他人脸；face_attribute_gt 是指人脸属性篡改，将图片中人脸的表情属性进行了修改。
        对于文本篡改类型主要分为两种：text_swap 是指文本替换篡改，将与图片对应的文本替换为了其他文本，将整句话都发生了变化；text_attribute_gt 是指文本属性篡改，将图片对应的文本中个别替换为了其他词汇，使得语义发生了微妙的变化。
        如果以上篡改都未发生，则认为该图文为原始样本，返回 orig 为 True。
        
        请根据图片和文本，判断图片和文本是否被篡改、篡改类型，如果人脸有发生篡改，请定位出篡改人脸的区域。定位使用的图像框使用像素坐标，顺序为[x1,y1,x2,y2]，与图片同一分辨率。
        输出的结果仅输出一个JSON对象，格式如下：
        {
            “orig”: True/False,
            "face_swap": True/False,
            "face_attribute": True/False,
            "text_swap": True/False,
            "text_attribute": True/False,
            "image_fake_boxes": [[x1,y1,x2,y2], ...], (篡改人脸的区域，如果face_swap或者face_attribute为 True时必填,否则返回空列表即可)
        }
        例如：
        {
            "orig": False,
            "face_swap": True,
            "face_attribute": False,
            "text_swap": False,
            "text_attribute": False,
            "image_fake_boxes": [[104,7,150,65]]
        }
        
        ''' + f"现在，当前的配文为：{text}。对应图像为上图。请直接给出输出的json结果，不要包含多余文字。"
        )

        return prompt
    
    def _run_vlm(self, image: Image.Image, prompt: str) -> str:
        try:
            messages = [{"role": "user", "content": [{"type": "image", "min_pixels": 40000, "max_pixels": 409600}, {"type": "text", "text": prompt}]}]
            text = self.processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
            inputs = self.processor(text=[text], images=[image], padding=True, return_tensors="pt").to(self.device)
            with torch.no_grad():
                output_ids = self.model.generate(
                    **inputs,
                    max_new_tokens=1024,
                    do_sample=False,
                    temperature=0.0
                )
            generated_ids = [output_ids[len(input_ids):] for input_ids, output_ids in zip(inputs.input_ids, output_ids)]
            # generated_ids = generated_ids[:, inputs["input_ids"].shape[1]:]
            out = self.processor.batch_decode(generated_ids, skip_special_tokens=True)[0]
  
            input_height = inputs['image_grid_thw'][0][1]*14
            input_width = inputs['image_grid_thw'][0][2]*14
            
            return out.strip(), input_height, input_width
        except Exception as e:
            print(f"[ERROR] 推理失败: {e}")
            return "", 0, 0

    def _safe_json_parse(self, s: str) -> Dict[str, Any]:
        # 尝试找到第一个JSON对象
        try:
            # 直解析
            return json.loads(s)
        except:
            # 尝试提取花括号内容
            m = re.search(r"\{.*\}", s, flags=re.S)
            if not m:
                return {}
            try:
                return json.loads(m.group(0))
            except:
                return {}

    def _parse_prediction(self, raw: str, img_height, img_width, im):
        
        
        data = self._safe_json_parse(raw)
        if not data:
            return None
        
        return_content = {
            "return_success": False,
            "pred_class": data.get("orig", None),
            "face_swap_pred": data.get("face_swap", None),
            "face_attribute_pred": data.get("face_attribute", None),
            "text_swap_pred": data.get("text_swap", None),
            "text_attribute_pred": data.get("text_attribute", None),
            "fake_face_pred_boxes": data.get("image_fake_boxes", [])
        }

        if return_content["pred_class"] == None or return_content["face_swap_pred"] is None or return_content["face_attribute_pred"] is None or return_content["text_swap_pred"] is None or return_content["text_attribute_pred"] is None:
            return_content["return_success"] = False
        else:
            return_content["return_success"] = True
        
        if return_content["return_success"]:
            width, height = im.size

            for idx in range(len(return_content["fake_face_pred_boxes"])):
                x1, y1, x2, y2 = return_content["fake_face_pred_boxes"][idx]
                x1 = max(int(x1/img_width*width),0)
                y1 = max(int(y1/img_height*height),0)
                x2 = min(int(x2/img_width*width),width)
                y2 = min(int(y2/img_height*height),height)
                if x1 > x2:
                    x1, x2 = x2, x1
                if y1 > y2:
                    y1, y2 = y2, y1
                    
                return_content["fake_face_pred_boxes"][idx] =  [x1, y1, x2, y2]
                
        return return_content
    
    def evaluate_sample(self, sample: Dict[str, Any]) -> SampleResult:
        image_path = sample.get("image", "")
        text = sample.get("text", "")
        gt_class = self._normalize_class(sample.get("fake_cls", "unknown"))
        
        if gt_class["read_success"] == False: 
            print("识别有误")
            print(sample)
            return None
        
        gt_boxes = sample.get("fake_image_box", [])

        img = self._open_image(image_path)
        if img is None:
            print("打开图片失败")
            return None

        prompt = self._build_prompt(text)
        raw_resp, img_height, img_width = self._run_vlm(img, prompt)
        
        if raw_resp == "":
            print("推理结果为空")
            print(f"{image_path}\n", f"{text}\n")
            return None
        
        return_content = self._parse_prediction(raw_resp, img_height, img_width, img)
        
        if return_content['return_success'] is False:
            print("解析结果失败")
            print(f"{image_path}\n", f"{text}\n")
            print(raw_resp)
            return None
        

        # per-sample metrics
        res = SampleResult(
            image_path=image_path,
            text=text,
            gt_class= gt_class["gt_class"],
            pred_class= return_content["pred_class"],
            face_swap_gt = gt_class["face_swap_gt"],
            face_attribute_gt = gt_class["face_attribute_gt"],
            text_swap_gt = gt_class["text_swap_gt"],
            text_attribute_gt = gt_class["text_attribute_gt"],
            fake_face_gt_boxes = gt_boxes,
            face_swap_pred = return_content["face_swap_pred"],
            face_attribute_pred = return_content["face_attribute_pred"],
            text_swap_pred = return_content["text_swap_pred"],
            text_attribute_pred = return_content["text_attribute_pred"],
            fake_face_pred_boxes = return_content["fake_face_pred_boxes"]
        )

        return res
    
    def load_test_data(self, json_path: str) -> List[Dict[str, Any]]:
        with open(json_path, "r", encoding="utf-8") as f:
            data = json.load(f)
    def run(self, test_json_path: str, output_dir: str = "./results", limit: int = None, topk: int = 10):
        os.makedirs(output_dir, exist_ok=True)
        data = self.load_test_data(test_json_path)
        
        if limit is not None and len(data) > limit:
            data = data[:limit]

        results: List[SampleResult] = []
        
        for sample in tqdm(data, desc="Evaluating"):
            r = self.evaluate_sample(sample)
            if r:
                results.append(r)
                # 累积用于宏观指标
                self.single_cls_preds.append(r.pred_class)
                self.single_cls_gts.append(r.gt_class)
                
                self.face_swap_cls_preds.append(r.face_swap_pred)
                self.face_swap_cls_gts.append(r.face_swap_gt)
                
                self.face_attribute_cls_preds.append(r.face_attribute_pred)
                self.face_attribute_cls_gts.append(r.face_attribute_gt)
                
                self.text_swap_cls_preds.append(r.text_swap_pred)
                self.text_swap_cls_gts.append(r.text_swap_gt)
                
                self.text_attribute_cls_preds.append(r.text_attribute_pred)
                self.text_attribute_cls_gts.append(r.text_attribute_gt)
                
            else:
                print(f"Skipping sample: {sample}")

        # 计算分类指标
        cls_metrics = {}
        valid_mask = [i for i, (p, g) in enumerate(zip(self.cls_preds, self.cls_gts)) if p != "unknown" and g in self.class_names]
        if valid_mask:
            y_pred = [self.cls_preds[i] for i in valid_mask]
            y_true = [self.cls_gts[i] for i in valid_mask]
            cls_acc = accuracy_score(y_true, y_pred)
            cls_prec, cls_rec, cls_f1, _ = precision_recall_fscore_support(y_true, y_pred, average="weighted", labels=self.class_names, zero_division=0)
            cm = confusion_matrix(y_true, y_pred, labels=self.class_names)
            cls_metrics = {
                "accuracy": cls_acc,
                "precision": cls_prec,
                "recall": cls_rec,
                "f1": cls_f1,
                "labels": self.class_names,
                "confusion_matrix": cm.tolist()
            }

        # 计算定位指标（图像）：对所有样本聚合TP/FP/FN与IoU
        total_tp = total_fp = total_fn = 0
        iou_list = []
        for preds, gts in zip(self.img_loc_preds, self.img_loc_gts):
            tp, fp, fn, avg_iou = self._match_boxes(preds, gts)
            total_tp += tp
            total_fp += fp
            total_fn += fn
            if avg_iou > 0:
                iou_list.append(avg_iou)
        img_prec, img_rec, img_f1 = self._prf1(total_tp, total_fp, total_fn)
        img_loc_metrics = {
            "precision": img_prec,
            "recall": img_rec,
            "f1": img_f1,
            "avg_iou_matched": float(np.mean(iou_list)) if iou_list else 0.0,
            "iou_thresh": self.iou_thresh
        }

        # 计算定位指标（文本token）
        tp_tok = fp_tok = fn_tok = 0
        for pred_t, gt_t in zip(self.txt_loc_preds, self.txt_loc_gts):
            pset, gset = set(pred_t), set(gt_t)
            tp_tok += len(pset & gset)
            fp_tok += len(pset - gset)
            fn_tok += len(gset - pset)
        txt_prec, txt_rec, txt_f1 = self._prf1(tp_tok, fp_tok, fn_tok)
        txt_loc_metrics = {
            "precision": txt_prec,
            "recall": txt_rec,
            "f1": txt_f1
        }

        # 排序找best/bad cases
        sorted_res = sorted(results, key=lambda x: x.score, reverse=True)
        best_cases = sorted_res[:min(topk, len(sorted_res))]
        worst_cases = sorted_res[-min(topk, len(sorted_res)):]

        # 可视化保存
        vis_dir_best = os.path.join(output_dir, "best_cases")
        vis_dir_worst = os.path.join(output_dir, "bad_cases")
        os.makedirs(vis_dir_best, exist_ok=True)
        os.makedirs(vis_dir_worst, exist_ok=True)
        for i, r in enumerate(best_cases):
            self.visualize_sample(r, os.path.join(vis_dir_best, f"best_{i:02d}.png"))
        for i, r in enumerate(worst_cases):
            self.visualize_sample(r, os.path.join(vis_dir_worst, f"bad_{i:02d}.png"))

        # 保存详细与汇总
        detailed = []
        for r in results:
            detailed.append({
                "image_path": r.image_path,
                "text": r.text,
                "gt_class": r.gt_class,
                "pred_class": r.pred_class,
                "gt_boxes": r.gt_boxes,
                "pred_boxes": r.pred_boxes,
                "gt_tokens": r.gt_tokens,
                "pred_tokens": r.pred_tokens,
                "class_correct": r.class_correct,
                "img_precision": r.img_prec,
                "img_recall": r.img_rec,
                "img_f1": r.img_f1,
                "img_avg_iou": r.img_avg_iou,
                "txt_precision": r.txt_prec,
                "txt_recall": r.txt_rec,
                "txt_f1": r.txt_f1,
                "score": r.score,
                "response": r.json_response if r.json_response else r.raw_response
            })
        with open(os.path.join(output_dir, "detailed_results.json"), "w", encoding="utf-8") as f:
            json.dump(detailed, f, ensure_ascii=False, indent=2)

        summary = {
            "num_samples": len(results),
            "classification_metrics": cls_metrics,
            "image_localization_metrics": img_loc_metrics,
            "text_localization_metrics": txt_loc_metrics,
            "best_cases": [{
                "image_path": r.image_path,
                "gt_class": r.gt_class,
                "pred_class": r.pred_class,
                "img_avg_iou": r.img_avg_iou,
                "img_f1": r.img_f1,
                "txt_f1": r.txt_f1,
                "score": r.score
            } for r in best_cases],
            "bad_cases": [{
                "image_path": r.image_path,
                "gt_class": r.gt_class,
                "pred_class": r.pred_class,
                "img_avg_iou": r.img_avg_iou,
                "img_f1": r.img_f1,
                "txt_f1": r.txt_f1,
                "score": r.score
            } for r in worst_cases]
        }
        with open(os.path.join(output_dir, "summary.json"), "w", encoding="utf-8") as f:
            json.dump(summary, f, ensure_ascii=False, indent=2)

        # 绘制并保存混淆矩阵（如有）
        if cls_metrics.get("confusion_matrix"):
            self._save_confusion_matrix(np.array(cls_metrics["confusion_matrix"]),
                                        cls_metrics["labels"],
                                        os.path.join(output_dir, "confusion_matrix.png"))

        print("评估完成。结果保存在：", output_dir)
        return summary, detailed